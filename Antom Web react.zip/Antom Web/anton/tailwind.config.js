/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      keyframes: {
        expand: {
          '0%': {transform: 'scaleX(1)'},
          '100%': {transform: 'scaleX(1.05)'},
        },
        showText: {
          '0%': {transform: 'translateY(100%)', opacity: 0},
          '100%': {transform: 'translateY(0)', opacity: 1},
        },
      },
      animation: {
        expand: 'expand 0.3s forwards',
        showText: 'showText 0.3s forwards',
      },
      transitionProperty: {
        height: 'height',
      },
    },
  },
  variants: {
    extend: {
      transform: ['hover'],
      translate: ['hover'],
      opacity: ['hover'],
    },
  },
  plugins: [],
};
