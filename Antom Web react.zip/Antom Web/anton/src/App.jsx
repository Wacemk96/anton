import {Fragment} from 'react';
import Frontpage from './pages/Frontpage';

function App() {
  return (
    <Fragment>
      <Frontpage />
    </Fragment>
  );
}

export default App;
