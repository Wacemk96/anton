import React from 'react';

const Herosection = () => {
  return (
    <div class="flex relative flex-col px-20 mt-28 w-full text-lg max-md:px-5 max-md:mt-10 max-md:max-w-full">
      <h1 class="text-7xl font-semibold text-white leading-[86px] max-md:max-w-full max-md:text-4xl max-md:leading-[53px]">
        Global Oil & Gas Industry
      </h1>
      <p class="mt-9 leading-7 text-white max-md:max-w-full">
        Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum
        est a, mattis tellus. Sed dignissim, metus nec fringilla accumsan, risus sem sollicitudin
        lacus, ut interdum tellus elit sed risus.
      </p>
      <div class="flex gap-5 justify-between self-start mt-11 font-medium text-center max-md:mt-10">
        <a
          href="#learn-more"
          class="px-7 py-3.5 text-black bg-white rounded-[50px] max-md:px-5"
        >
          Learn More
        </a>
        <button class="px-7 py-3.5 text-white border border-white border-solid rounded-[50px] max-md:px-5">
          Watch Video
        </button>
      </div>
      <img
        loading="lazy"
        src="https://cdn.builder.io/api/v1/image/assets/TEMP/92c20f90f5b93056730a30a0aed7b30d5e197498491ddd77c662e3a33de58ef1?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
        alt="Decorative element"
        class="self-end mt-16 aspect-[5.88] w-[60px] max-md:mt-10"
      />
    </div>
  );
};

export default Herosection;
