import React, {Fragment} from 'react';

const Footer = () => {
  return (
    <Fragment>
      <footer class="flex gap-5 items-start p-20 mt-16 w-full bg-blue-950 max-md:flex-wrap max-md:px-5 max-md:mt-10 max-md:max-w-full">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/9c882cccf088737d8b58557527946d36cc83d444d2ae38b2b7b5f217c966502c?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
          alt="Anton Group logo"
          class="shrink-0 max-w-full aspect-[2.5] w-[200px]"
        />
        <div class="flex-auto max-md:max-w-full">
          <div class="flex gap-5 max-md:flex-col">
            <div class="flex flex-col w-[21%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col text-white max-md:mt-10">
                <h4 class="text-lg font-semibold">Anton Group</h4>
                <nav class="mt-4 text-base font-medium leading-7">
                  <ul>
                    <li>
                      <a href="#anton-online">Anton Online</a>
                    </li>
                    <li>
                      <a href="#at-mall">AT Mall</a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
            <div class="flex flex-col ml-5 w-[23%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col grow text-white max-md:mt-10">
                <h4 class="text-xl font-semibold">Quick Links</h4>
                <nav class="mt-4 text-base font-medium leading-7">
                  <ul>
                    <li>
                      <a href="#services">Our Services</a>
                    </li>
                    <li>
                      <a href="#industries">Industries</a>
                    </li>
                    <li>
                      <a href="#group">Anton Oil Group</a>
                    </li>
                    <li>
                      <a href="#about">About Us</a>
                    </li>
                    <li>
                      <a href="#contact">Contact Us</a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
            <div class="flex flex-col ml-5 w-[19%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col text-white whitespace-nowrap max-md:mt-10">
                <h4 class="text-lg font-semibold">Information</h4>
                <nav class="mt-4 text-base font-medium leading-7">
                  <ul>
                    <li>
                      <a href="#faqs">FAQS</a>
                    </li>
                    <li>
                      <a href="#careers">Careers</a>
                    </li>
                    <li>
                      <a href="#news">News</a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
            <div class="flex flex-col ml-5 w-[38%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col max-md:mt-10">
                <h4 class="text-xl font-semibold text-white">Support</h4>
                <div class="flex gap-1.5 mt-4 text-base font-medium text-white whitespace-nowrap">
                  <img
                    loading="lazy"
                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/ea4e128ce875fe0a83b1b91f0e56ae0b906eba6545b1c2cbc25626c66f93968a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                    alt="Email icon"
                    class="shrink-0 aspect-square w-[25px]"
                  />
                  <a
                    href="mailto:info@anton.com"
                    class="flex-auto my-auto"
                  >
                    info@anton.com
                  </a>
                </div>
                <div class="flex gap-1.5 mt-2 text-base font-medium text-white">
                  <img
                    loading="lazy"
                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/c6fde3662caa201e0f521104d4f51dfe18f8a7e254217bf44f7a63e0b7ea7e7a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                    alt="Phone icon"
                    class="shrink-0 aspect-square w-[25px]"
                  />
                  <a
                    href="tel:+xxxxxxxxxxxxx"
                    class="flex-auto my-auto"
                  >
                    +xxx xx xxx xxxx
                  </a>
                </div>
                <div class="flex gap-1.5 mt-2 text-base font-medium text-white">
                  <img
                    loading="lazy"
                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/abeff5e7234c3036733ee7486fd9441816e1ad31af651711fac0d30f6828f593?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                    alt="Location icon"
                    class="shrink-0 aspect-square w-[25px]"
                  />
                  <address class="flex-auto my-auto not-italic">Lorem lipsum mesum</address>
                </div>
                <div class="flex gap-4 pr-16 mt-4 max-md:pr-5">
                  <a
                    href="#"
                    aria-label="Facebook"
                  >
                    <img
                      loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/1ae814a5c4b057356491906777f8778ff23906a38f6453e629845d35a0338169?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                      alt=""
                      class="shrink-0 aspect-square w-[18px]"
                    />
                  </a>
                  <a
                    href="#"
                    aria-label="Twitter"
                  >
                    <img
                      loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/305b895064728b265dd2cf7b0e6f1ea2cb847085291fa8d4c668e7302a913731?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                      alt=""
                      class="shrink-0 aspect-square w-[18px]"
                    />
                  </a>
                  <a
                    href="#"
                    aria-label="LinkedIn"
                  >
                    <img
                      loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/2a89405be6ba4270edbe03f522b43b55b089001f2b235a5d37a52f3f59020834?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                      alt=""
                      class="shrink-0 aspect-square w-[18px]"
                    />
                  </a>
                  <a
                    href="#"
                    aria-label="Instagram"
                  >
                    <img
                      loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/f153b69d24eeb8a1a8d6b41a2a2ed01e2bd3afc08c3995cfb589d9de7da4cfdc?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                      alt=""
                      class="shrink-0 aspect-square w-[18px]"
                    />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <div class="flex gap-5 px-20 py-5 w-full text-base font-medium text-white border-t border-white bg-blue-950 max-md:flex-wrap max-md:px-5 max-md:max-w-full">
        <p class="flex-auto">Designed and Managed by Prism</p>
        <div class="flex gap-5">
          <a
            href="#terms"
            class="flex-auto"
          >
            Terms of Service
          </a>
          <a
            href="#privacy"
            class="text-right"
          >
            Privacy Policy
          </a>
        </div>
      </div>
    </Fragment>
  );
};

export default Footer;
