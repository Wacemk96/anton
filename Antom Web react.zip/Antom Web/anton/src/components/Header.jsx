import React, {useState, useEffect} from 'react';
import Herosection from './Herosection';
import './style/bgimage.css';

const Header = () => {
  const [image, setImage] = useState(
    'https://cdn.builder.io/api/v1/image/assets/TEMP/1ebcead4d621ae80ee36084ebdbed80f52a00e3638cb747cd3d8fce0273c523a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf'
  );
  const [fade, setFade] = useState(false);

  const images = [
    'https://cdn.builder.io/api/v1/image/assets/TEMP/1ebcead4d621ae80ee36084ebdbed80f52a00e3638cb747cd3d8fce0273c523a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf',
    'https://images.pexels.com/photos/3855962/pexels-photo-3855962.jpeg',
    'https://images.pexels.com/photos/799096/pexels-photo-799096.jpeg',
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setFade(true);

      setTimeout(() => {
        setImage((prevImage) => {
          const currentIndex = images.indexOf(prevImage);
          const nextIndex = (currentIndex + 1) % images.length;
          return images[nextIndex];
        });
        setFade(false);
      }, 1000); // Duration of fade-out before changing image
    }, 5000); // Change image every 5 seconds

    return () => clearInterval(interval);
  }, [images]);
  return (
    <header class="flex relative flex-col pb-20 w-full min-h-[723px] max-md:max-w-full">
      <img
        loading="lazy"
        src={image}
        alt="Background image of oil field"
        className={`object-cover absolute inset-0 size-full ${fade ? 'fade-up' : ''}`}
      />
      <nav class="flex relative gap-5 justify-between items-center px-20 py-8 w-full text-base font-medium text-center text-white border-b border-white border-opacity-30 max-md:flex-wrap max-md:px-5 max-md:max-w-full">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/8215344cf41037386a944648870b34ceaeec2a5dc3af37e27550c43b6ddf4c96?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
          alt="Company logo"
          class="shrink-0 self-stretch max-w-full aspect-[2.5] w-[100px]"
        />
        <ul class="flex self-stretch my-auto max-md:flex-wrap">
          <li>
            <a
              href="#about"
              class="px-3 py-1.5"
            >
              About Us
            </a>
          </li>
          <li>
            <a
              href="#services"
              class="px-3 py-1.5"
            >
              Our Services
            </a>
          </li>
          <li>
            <a
              href="#industries"
              class="px-3 py-1.5 whitespace-nowrap"
            >
              Industries
            </a>
          </li>
          <li>
            <a
              href="#group"
              class="px-3 py-1.5"
            >
              Anton Oil Group
            </a>
          </li>
          <li>
            <a
              href="#news"
              class="px-3 py-1.5 whitespace-nowrap"
            >
              News
            </a>
          </li>
          <li>
            <a
              href="#contact"
              class="px-3 py-1.5"
            >
              Contact Us
            </a>
          </li>
        </ul>
        <div class="flex gap-3.5 self-stretch my-auto whitespace-nowrap">
          <button class="px-5 py-1.5">En</button>
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/0c93495ce4151afe871a4c576287403d9a8ff81ccf1227ffb1e2d065937ffd85?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
            alt="Language selection icon"
            class="shrink-0 aspect-square w-[31px]"
          />
        </div>
      </nav>
      <Herosection />
    </header>
  );
};

export default Header;
