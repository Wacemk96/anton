import React, {Fragment} from 'react';
import 'tailwindcss/tailwind.css';

const Frontpage = () => {
  return (
    <Fragment>
      <section
        id="about"
        class="flex justify-center items-center px-16 py-16 w-full bg-white max-md:px-5 max-md:max-w-full"
      >
        <div class="flex flex-col items-center w-full max-w-[1185px] max-md:max-w-full">
          <h2 class="text-lg font-medium leading-7 text-center text-red-700">ABOUT US</h2>
          <h3 class="mt-7 text-5xl font-semibold text-center text-black leading-[57.6px] max-md:max-w-full max-md:text-4xl">
            Learn about our History, Mission & Values
          </h3>
          <p class="self-stretch mt-8 text-base leading-6 text-center text-black max-md:max-w-full">
            Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie,
            dictum est a, mattis tellus. Sed dignissim, metus nec fringilla accumsan, risus sem
            sollicitudin lacus, ut interdum tellus elit sed risus. Gorem ipsum dolor sit amet,
            consectetur adipiscing elit. Gorem ipsum dolor sit amet, consectetur. Gorem ipsum dolor
            sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis
            tellus. Sed dignissim, metus nec fringilla accumsan, risus sem sollicitudin lacus, ut
            interdum tellus elit sed risus. Gorem ipsum dolor sit amet, consectetur adipiscing elit.
            Gorem ipsum dolor sit amet, consectetur.
          </p>
          <div class="mt-10 max-w-full w-[936px]">
            <div class="flex gap-5 max-md:flex-col">
              <div class="flex flex-col w-[24%] max-md:ml-0 max-md:w-full">
                <div class="flex flex-col text-center max-md:mt-10">
                  <p class="self-center text-5xl font-semibold text-black leading-[57.6px] max-md:text-4xl">
                    #1
                  </p>
                  <p class="mt-7 text-base font-medium leading-6 text-black">
                    China's Largest Private Oilfield Group
                  </p>
                </div>
              </div>
              <div class="flex flex-col ml-5 w-[53%] max-md:ml-0 max-md:w-full">
                <div class="flex grow gap-3 text-center max-md:mt-10">
                  <div class="flex flex-col self-start">
                    <p class="self-center text-5xl font-semibold text-black leading-[57.6px] max-md:text-4xl">
                      12+
                    </p>
                    <p class="mt-7 text-base font-medium leading-6 text-black">
                      Years of Oilfield Management
                    </p>
                  </div>
                  <div class="flex flex-col grow shrink-0 basis-0 w-fit">
                    <div class="flex flex-col self-end px-px max-w-full w-[133px]">
                      <p class="self-center text-5xl font-semibold text-black leading-[57.6px] max-md:text-4xl">
                        30+
                      </p>
                      <p class="mt-7 text-base font-medium leading-6 text-black">
                        Million of LTIR free manhouse
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="flex flex-col ml-5 w-[23%] max-md:ml-0 max-md:w-full">
                <div class="flex flex-col text-center max-md:mt-10">
                  <p class="self-center text-5xl font-semibold text-black leading-[57.6px] max-md:text-4xl">
                    400K
                  </p>
                  <p class="mt-7 text-base font-medium leading-6 text-black">
                    Barrels of Oil Production Capacity
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="py-10">
            <a
              href="#learn-more"
              class="px-5 py-3.5 mt-12 text-base font-medium text-black border border-black border-solid rounded-[50px] max-md:pl-5 max-md:mt-10 hover:bg-blue-800 hover:text-white transition duration-300"
            >
              Learn More
            </a>
          </div>
        </div>
      </section>

      <section
        id="services"
        class="px-5 w-full max-md:max-w-full"
      >
        <div class="flex max-md:flex-col">
          <div class="flex flex-col w-3/12 max-md:ml-0 max-md:w-full">
            <div class="flex relative flex-col grow px-6 pt-96 pb-10 text-2xl font-semibold leading-9 text-white aspect-[0.72] max-md:px-5 max-md:pt-10">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/acd572bfe7f388e193c38f2c867f70e390142fbfc8460050dabd28de5c184b37?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt="Integrated Oilfield Management Service"
                class="object-cover absolute inset-0 size-full"
              />
              <h3 className="z-10 -mt-10">Integrated Oilfield Management Service</h3>
              <p className="z-10 text-sm py-5 hidden">
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ad quaerat tenetur
                possimus accusantium aliquam, inventore, iusto harum nihil sit quam quos nemo quod,
                mollitia aliquid cumque ipsam unde! Quia, accusamus.
              </p>
            </div>
          </div>
          <div class="flex flex-col w-3/12 max-md:ml-0 max-md:w-full">
            <div class="flex relative flex-col grow px-6 pt-96 pb-10 text-2xl font-semibold leading-9 text-white aspect-[0.72] max-md:px-5 max-md:pt-10">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/7b41300ee15cddbbd3e059b314ce4a569528f0d202c7abc428ef4a34d35588e0?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt="Oilfield Operation & Maintenance Service"
                class="object-cover absolute inset-0 size-full"
              />
              <h3>
                Oilfield Operation <br /> & Maintenance Service
              </h3>
            </div>
          </div>
          <div class="flex flex-col w-3/12 max-md:ml-0 max-md:w-full">
            <div class="flex relative flex-col grow px-6 pt-96 pb-10 text-2xl font-semibold leading-9 text-white aspect-[0.72] max-md:px-5 max-md:pt-10">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/449272268cdc7c7f11710617bae25b34003f3df4be996240ba11567b157863b4?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt="Supervision & Personnel Service"
                class="object-cover absolute inset-0 size-full"
              />
              <h3>
                Supervision & <br /> Personnel Service
              </h3>
            </div>
          </div>
          <div class="flex flex-col w-3/12 max-md:ml-0 max-md:w-full">
            <div class="flex relative flex-col grow px-6 pt-80 pb-10 text-2xl font-semibold leading-9 text-white aspect-[0.72] max-md:px-5 max-md:pt-10">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/3348e587e8c9906214aabaf21d58dc79ddf6ae314279e76247595a208d8cd61b?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt="Oilfield Development Investment & Management Services"
                class="object-cover absolute inset-0 size-full"
              />
              <h3>
                Oilfield Development Investment & <br /> Management Services
              </h3>
            </div>
          </div>
        </div>
      </section>

      <section class="flex flex-col items-center px-20 py-20 w-full bg-white max-md:px-5 max-md:max-w-full">
        <h2 class="text-lg font-medium leading-7 text-center text-red-700">OUR ECOSYSTEM</h2>
        <h3 class="mt-7 text-5xl font-semibold text-center text-black leading-[57.6px] max-md:text-4xl">
          Why Choose Us
        </h3>
        <div class="self-stretch mt-11 max-md:mt-10 max-md:max-w-full">
          <div class="flex gap-5 max-md:flex-col">
            <article class="flex flex-col w-[33%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col grow items-start py-8 pr-16 pl-6 text-black rounded-2xl border border-solid border-black border-opacity-20 max-md:px-5 max-md:mt-10">
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/5eb9415e5c8a44a56265dab126d5f4ec8c4a28689f5294d2731334491954d7d4?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                  alt="Easy Scale of Operations icon"
                  class="rounded-lg aspect-square w-[85px]"
                />
                <h4 class="mt-6 text-2xl font-semibold leading-8">Easy Scale of Operations</h4>
                <p class="mt-5 text-base leading-6">
                  Gorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et
                  velit interdum, ac aliquet odio
                </p>
              </div>
            </article>
            <article class="flex flex-col ml-5 w-[33%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col grow items-start py-8 pr-16 pl-6 text-black rounded-2xl border border-solid border-black border-opacity-20 max-md:px-5 max-md:mt-10">
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/9c8914a27e5855e88acfed77170c51ac753c51cfebe859f56804b2765b95213c?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                  alt="Market Speed & Proximity icon"
                  class="rounded-lg aspect-square w-[85px]"
                />
                <h4 class="mt-6 text-2xl font-semibold leading-8">Market Speed & Proximity</h4>
                <p class="mt-5 text-base leading-6">
                  Gorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et
                  velit interdum, ac aliquet odio
                </p>
              </div>
            </article>
            <article class="flex flex-col ml-5 w-[33%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col grow items-start py-8 pr-16 pl-6 text-black rounded-2xl border border-solid border-black border-opacity-20 max-md:px-5 max-md:mt-10">
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/d63cb319a18261d1199c6439e0212a333e6addc8747baad4e778cc4890bdcbd7?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                  alt="Significant Cost Savings icon"
                  class="rounded-lg aspect-square w-[85px]"
                />
                <h4 class="mt-6 text-2xl font-semibold leading-8">Significant Cost Savings</h4>
                <p class="mt-5 text-base leading-6">
                  Gorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et
                  velit interdum, ac aliquet odio
                </p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section class="flex relative flex-col py-20 w-full min-h-[800px] max-md:max-w-full">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/abd4e3a9b1f04467171edadf92a6647c416f9efca7be416777803325e79b7846?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
          alt="Background image for services section"
          class="object-cover absolute inset-0 size-full"
        />
        <div class="relative self-center mt-9 w-full max-w-screen-xl max-md:max-w-full">
          <div class="flex gap-5 max-md:flex-col">
            <div class="flex flex-col w-[57%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col text-white self-start">
                <h2 class="text-lg font-medium leading-7">WHAT WE DO</h2>
                <h3 class="mt-7 text-5xl font-semibold leading-[57.6px] max-md:text-4xl">
                  Our Services
                </h3>
              </div>
              <div class="flex relative mt-52 flex-col grow text-base text-white max-md:mt-10 max-md:max-w-full">
                <h3 class="text-5xl font-semibold leading-[58px] max-md:max-w-full max-md:text-4xl max-md:leading-[54px]">
                  Integrated Oilfield <br /> Management Service
                </h3>
                <p class="mt-6 leading-6 max-md:max-w-full">
                  Morem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et
                  velit interdum, ac aliquet odio mattis. Class aptent taciti sociosqu ad litora
                  torquent per conubia nostra, per inceptos himenaeos.
                </p>
                <a
                  href="#learn-more"
                  class="self-start px-5 py-3.5 mt-7 font-medium text-center text-black bg-white rounded-[50px] max-md:pl-5"
                >
                  Learn More
                </a>
              </div>
            </div>
            <div class="flex flex-col ml-5 w-[43%] max-md:ml-0 max-md:w-full">
              <div class="flex relative grow gap-5 items-start mt-5 max-md:flex-wrap max-md:mt-10">
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/1efed5835c761d34d2fc2294ca5b4957e9f3edbfe8fc54d287e1c153826b791a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                  alt="Oilfield Development Investment & Management Services icon"
                  class="shrink-0 w-11 aspect-square"
                />
                <div class="flex flex-col grow shrink-0 px-5 mt-2 basis-0 w-fit max-md:max-w-full">
                  <h4 class="text-3xl font-semibold leading-10 text-white max-md:max-w-full">
                    Oilfield Operation & Maintenance Service
                  </h4>
                  <p class="mt-6 text-base leading-6 text-white max-md:max-w-full">
                    Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis
                    molestie, dictum est a, mattis tellus
                  </p>
                </div>
              </div>

              <div class="flex relative grow gap-5 items-start mt-5 max-md:flex-wrap max-md:mt-10">
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/1efed5835c761d34d2fc2294ca5b4957e9f3edbfe8fc54d287e1c153826b791a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                  alt="Oilfield Development Investment & Management Services icon"
                  class="shrink-0 w-11 aspect-square"
                />
                <div class="flex flex-col grow shrink-0 px-5 mt-2 basis-0 w-fit max-md:max-w-full">
                  <h4 class="text-3xl font-semibold leading-10 text-white max-md:max-w-full">
                    Supervision & Personnel Service
                  </h4>
                  <p class="mt-6 text-base leading-6 text-white max-md:max-w-full">
                    Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis
                    molestie, dictum est a, mattis tellus
                  </p>
                </div>
              </div>

              <div class="flex relative grow gap-5 items-start mt-5 max-md:flex-wrap max-md:mt-10">
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/1efed5835c761d34d2fc2294ca5b4957e9f3edbfe8fc54d287e1c153826b791a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                  alt="Oilfield Development Investment & Management Services icon"
                  class="shrink-0 w-11 aspect-square"
                />
                <div class="flex flex-col grow shrink-0 px-5 mt-2 basis-0 w-fit max-md:max-w-full">
                  <h4 class="text-3xl font-semibold leading-10 text-white max-md:max-w-full">
                    Oilfield Development Investment & Management Services
                  </h4>
                  <p class="mt-6 text-base leading-6 text-white max-md:max-w-full">
                    Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis
                    molestie, dictum est a, mattis tellus
                  </p>
                  <div class="flex gap-3.5 self-end mt-7">
                    <img
                      loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/bcff1ee0584de718bbc5d6c1d8a9c59487921a9d81ce50410987388b11d3bbee?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                      alt="Navigation arrow left"
                      class="shrink-0 w-11 aspect-square rounded-[100px]"
                    />
                    <img
                      loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/11f9be082896bb07e2b2267b9850d0c7cae368c4f6bdca53e9397784a963cf8c?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                      alt="Navigation arrow right"
                      class="shrink-0 w-11 aspect-square rounded-[100px]"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="flex flex-col items-center px-20 py-16 w-full bg-white max-md:px-5 max-md:max-w-full">
        <h2 class="self-center mt-16 text-lg font-medium leading-7 text-center text-red-700 max-md:mt-10">
          BUSINESS MAP
        </h2>
        <h3 class="self-center mt-7 text-5xl font-semibold text-center text-black leading-[57.6px] max-md:text-4xl">
          Strategic Locations
        </h3>
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/21bc63a23f5a6bb44d386399f628f85be1bf2da1fd9375bdbdd2174c69d5ff1c?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
          alt="Map showing strategic locations"
          class="self-center mt-11 max-w-full aspect-[1.61] w-[900px] max-md:mt-10"
        />
        <p class="self-center mt-11 text-base leading-6 text-center text-black text-opacity-50 max-md:mt-10 max-md:max-w-full">
          *Independently Manage 3 Oil and Gasfields Participates in the Management of 7 Oil and
          Gasfields*
        </p>
      </section>

      <section class="flex relative flex-col items-start px-14 py-16 mt-16 w-full min-h-[849px] max-md:px-5 max-md:mt-10 max-md:max-w-full">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/578ca661f1b320c351bb7f86f4dbf171e27ea89d191323540e96a55f84dead8d?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
          alt="Background image for projects section"
          class="object-cover absolute inset-0 size-full"
        />
        <div class="relative self-stretch max-md:max-w-full">
          <div class="flex gap-5 max-md:flex-col">
            <div class="flex flex-col w-[78%] max-md:ml-0 max-md:w-full">
              <article class="flex relative flex-col grow px-6 py-8 mt-7 w-full text-white rounded-2xl bg-black bg-opacity-20 max-md:px-5 max-md:mt-10 max-md:max-w-full">
                <h3 class="text-3xl font-semibold leading-10 max-md:max-w-full">
                  Majnoon Project in Iraq
                </h3>
                <p class="mt-6 text-base leading-6 max-md:max-w-full">
                  Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie,
                  dictum est a, mattis tellus. Sed dignissim, metus nec fringilla accumsan, risus
                  sem sollicitudin lacus, ut interdum tellus elit sed risus.
                </p>
              </article>
            </div>
            <div class="flex flex-col ml-5 w-[22%] max-md:ml-0 max-md:w-full">
              <div class="flex relative flex-col text-right text-white max-md:mt-10">
                <h2 class="self-end text-lg font-medium leading-7">WORK</h2>
                <h3 class="mt-7 text-5xl font-semibold leading-[57.6px] max-md:text-4xl">
                  Our Projects
                </h3>
              </div>
            </div>
          </div>
        </div>
        <article class="relative mt-14 ml-6 max-md:mt-10 max-md:ml-2.5">
          <h3 class="text-3xl font-semibold leading-10 text-white">Chad OPIC Project</h3>
          <p class="relative mt-6 text-base leading-6 text-white w-[863px] max-md:max-w-full">
            Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie,
            dictum est a, mattis tellus. Sed dignissim, metus nec fringilla accumsan, risus sem
            sollicitudin lacus, ut interdum tellus elit sed risus.
          </p>
        </article>
        <article class="relative mt-20 ml-6 max-md:mt-10 max-md:ml-2.5">
          <h3 class="text-3xl font-semibold leading-10 text-white">Buzur Dry Water Station</h3>
          <p class="relative mt-6 text-base leading-6 text-white w-[863px] max-md:max-w-full">
            Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie,
            dictum est a, mattis tellus. Sed dignissim, metus nec fringilla accumsan, risus sem
            sollicitudin lacus, ut interdum tellus elit sed risus.
          </p>
        </article>
        <article class="relative mt-20 ml-6 max-md:mt-10 max-md:ml-2.5">
          <h3 class="text-3xl font-semibold leading-10 text-white">Halfaya Oilfield</h3>
          <p class="relative mt-6 text-base leading-6 text-white w-[863px] max-md:max-w-full">
            Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie,
            dictum est a, mattis tellus. Sed dignissim, metus nec fringilla accumsan, risus sem
            sollicitudin lacus, ut interdum tellus elit sed risus.
          </p>
        </article>
      </section>

      <section class="flex flex-col items-center p-20 w-full bg-white max-md:px-5 max-md:max-w-full">
        <div class="self-stretch max-md:max-w-full">
          <div class="flex gap-5 max-md:flex-col">
            <div class="flex flex-col w-[26%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col mt-2 max-md:mt-10">
                <h2 class="text-lg font-medium leading-7 text-red-700">TESTIMONIALS</h2>
                <h3 class="mt-7 text-5xl font-semibold text-black leading-[58px] max-md:text-4xl max-md:leading-[54px]">
                  Why People Consider Us
                </h3>
              </div>
            </div>
            <div class="flex flex-col ml-5 w-[74%] max-md:ml-0 max-md:w-full">
              <div class="grow max-md:mt-10 max-md:max-w-full">
                <div class="flex gap-5 max-md:flex-col">
                  <div class="flex flex-col w-1/5 max-md:ml-0 max-md:w-full">
                    <img
                      loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/8c1c4e798109b0503654e597de98f10eba31e3cff688f99ab6d1e05bd2906847?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                      alt="Testimonial author"
                      class="shrink-0 max-w-full rounded-full aspect-square w-[166px] max-md:mt-10"
                    />
                  </div>
                  <blockquote class="flex flex-col ml-5 w-4/5 max-md:ml-0 max-md:w-full">
                    <div class="flex flex-col self-stretch my-auto text-black max-md:mt-10 max-md:max-w-full">
                      <p class="text-5xl font-semibold leading-[57.6px] max-md:max-w-full max-md:text-4xl">
                        "Porem ipsum"...
                      </p>
                      <p class="mt-8 text-base leading-6 max-md:max-w-full">
                        Gorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis
                        molestie, dictum est a, mattis tellus. Sed dignissim, metus nec fringilla
                        accumsan, risus sem sollicitudin lacus, ut interdum tellus elit sed risus.
                      </p>
                    </div>
                  </blockquote>
                </div>
              </div>
            </div>
          </div>
        </div>
        <cite class="mt-8 ml-20 text-base leading-6 text-black">Lorim Lipsum, Designer</cite>
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/79d3beead72becd34e7454f18d098c4bbff9c5784d9279c45eccd5daf11c3b0c?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
          alt="Rating stars"
          class="mt-7 aspect-[6.25] w-[62px]"
        />
      </section>

      <section class="flex relative flex-col justify-center w-full text-base text-center text-white min-h-[411px] max-md:max-w-full">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/TEMP/ff00a1007738ffeae19e7d0732117ced440cc2219dfea3303d7906a21bfbcf55?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
          alt="Background image for call to action"
          class="object-cover absolute inset-0 size-full"
        />
        <div class="flex relative justify-center items-center px-16 py-20 w-full bg-black bg-opacity-40 max-md:px-5 max-md:max-w-full">
          <div class="flex flex-col mt-4 mb-2 max-w-full w-[609px]">
            <h2 class="text-5xl font-semibold leading-[58px] max-md:max-w-full max-md:text-4xl max-md:leading-[54px]">
              From The Well To The Pump, <br /> We've Got You Covered
            </h2>
            <p class="mt-11 leading-[150%] max-md:mt-10 max-md:max-w-full">
              We look forward to partnering with you and delivering excellence in the oil industry.
            </p>
            <a
              href="#contact"
              class="self-center px-7 py-3.5 mt-7 font-medium text-black bg-white rounded-[50px] max-md:px-5"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>

      <section
        id="news"
        class="flex flex-col px-20 py-16 w-full bg-white max-md:px-5 max-md:max-w-full"
      >
        <div class="flex gap-5 justify-between w-full max-md:flex-wrap max-md:max-w-full">
          <div class="flex flex-col">
            <h2 class="text-lg font-medium leading-7 text-red-700">LATEST</h2>
            <h3 class="mt-7 text-5xl font-semibold text-black leading-[57.6px] max-md:text-4xl">
              News & Insights
            </h3>
          </div>
          <div class="flex gap-3.5 my-auto">
            <button
              aria-label="Previous news"
              class="shrink-0 w-11 aspect-square rounded-[100px]"
            >
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/8ae70db915dbbe858aa5286b284b82efbcaca659ff5ec94f5015b666da0841f2?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt=""
              />
            </button>
            <button
              aria-label="Next news"
              class="shrink-0 w-11 aspect-square rounded-[100px]"
            >
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/3ef802a9e2109a3d843240d2f1781d5fbd952e21612cc648b66acdc27661b76a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt=""
              />
            </button>
          </div>
        </div>
        <div class="mt-9 max-md:max-w-full">
          <div class="flex gap-5 max-md:flex-col">
            <div class="flex flex-col w-[43%] max-md:ml-0 max-md:w-full">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/fb84325f14abe38eb7f8d403f8ef1caf5d59296c61afa7e7edd74dfae04ea88d?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt="Featured news image"
                class="grow mt-1.5 w-full rounded-2xl aspect-[1.64] max-md:mt-10 max-md:max-w-full"
              />
            </div>
            <div class="flex flex-col ml-5 w-[57%] max-md:ml-0 max-md:w-full">
              <div class="max-md:mt-10 max-md:max-w-full">
                <div class="flex gap-5 max-md:flex-col">
                  <div class="flex flex-col w-[21%] max-md:ml-0 max-md:w-full">
                    <div class="flex flex-col grow items-center max-md:mt-6">
                      <img
                        loading="lazy"
                        src="https://cdn.builder.io/api/v1/image/assets/TEMP/0d998c1a4bb19053991b921a154ac5e8492be2caf626c0a7b139224584613fd6?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                        alt="News thumbnail 1"
                        class="rounded-lg aspect-[1.03] w-[140px]"
                      />
                      <img
                        loading="lazy"
                        src="https://cdn.builder.io/api/v1/image/assets/TEMP/ec02a656af560b4c2eab28852913b2e01e408ac559d86efdaaf63e7fc85becac?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                        alt="News thumbnail 2"
                        class="mt-10 rounded-lg aspect-[1.03] w-[140px]"
                      />
                    </div>
                  </div>
                  <div class="flex flex-col ml-5 w-[79%] max-md:ml-0 max-md:w-full">
                    <div class="flex flex-col self-stretch my-auto text-2xl font-semibold leading-9 text-black max-md:mt-9 max-md:max-w-full">
                      <h4 class="max-md:max-w-full">
                        Morem ipsum dolor sit amet, consectetur adipiscing elit.
                      </h4>
                      <p class="mt-5 text-base leading-6 max-md:max-w-full">
                        Porem ipsum dolor sit amet, consectetur adipiscing elit, Porem ipsum dolor
                        sit amet, consectetur adipiscing elit.
                      </p>
                      <h4 class="mt-14 max-md:mt-10 max-md:max-w-full">
                        Morem ipsum dolor sit amet, consectetur adipiscing elit.
                      </h4>
                      <p class="mt-5 text-base leading-6 max-md:max-w-full">
                        Porem ipsum dolor sit amet, consectetur adipiscing elit, Porem ipsum dolor
                        sit amet, consectetur adipiscing elit.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="mt-6 max-md:max-w-full">
          <div class="flex gap-5 max-md:flex-col">
            <article class="flex flex-col w-[43%] max-md:ml-0 max-md:w-full">
              <div class="flex flex-col text-black max-md:mt-10 max-md:max-w-full">
                <h4 class="text-2xl font-semibold leading-9 max-md:max-w-full">
                  Morem ipsum dolor sit amet, consectetur adipiscing elit.
                </h4>
                <p class="mt-5 text-base leading-6 max-md:max-w-full">
                  Porem ipsum dolor sit amet, consectetur adipiscing elit, Porem ipsum dolor sit
                  amet, consectetur adipiscing elit.
                </p>
              </div>
            </article>
            <div class="flex flex-col ml-5 w-[57%] max-md:ml-0 max-md:w-full">
              <div class="grow max-md:mt-10 max-md:max-w-full">
                <div class="flex gap-5 max-md:flex-col">
                  <div class="flex flex-col w-[21%] max-md:ml-0 max-md:w-full">
                    <img
                      loading="lazy"
                      src="https://cdn.builder.io/api/v1/image/assets/TEMP/a09509129a3d9ff87fa25639eb780235b71cc981a9e20a923c382959cfc054b2?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                      alt="News thumbnail 3"
                      class="grow shrink-0 max-w-full rounded-lg aspect-[1.03] w-[140px] max-md:mt-6"
                    />
                  </div>
                  <article class="flex flex-col ml-5 w-[79%] max-md:ml-0 max-md:w-full">
                    <div class="flex flex-col self-stretch my-auto text-black max-md:mt-9 max-md:max-w-full">
                      <h4 class="text-2xl font-semibold leading-9 max-md:max-w-full">
                        Morem ipsum dolor sit amet, consectetur adipiscing elit.
                      </h4>
                      <p class="mt-5 text-base leading-6 max-md:max-w-full">
                        Porem ipsum dolor sit amet, consectetur adipiscing elit, Porem ipsum dolor
                        sit amet, consectetur adipiscing elit.
                      </p>
                    </div>
                  </article>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="flex flex-col px-20 mt-6 w-full font-semibold text-black max-md:px-5 max-md:max-w-full">
        <div class="flex relative flex-col justify-center items-center px-16 py-20 font-medium text-center text-white rounded-3xl min-h-[332px] max-md:px-5 max-md:max-w-full">
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/TEMP/b8981279a08ebd89345739d47859b90c693bd735f1bd9bad84cc4a7f60869e19?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
            alt="Background for career section"
            class="object-cover absolute inset-0 size-full"
          />
          <div class="flex relative flex-col items-center mt-2 max-w-full w-[572px]">
            <h2 class="text-lg leading-7">JOIN OUR TEAM</h2>
            <h3 class="self-stretch mt-8 text-5xl font-semibold leading-[57.6px] max-md:max-w-full max-md:text-4xl">
              Grow Your Career At Anton
            </h3>
            <a
              href="#careers"
              class="px-5 py-3.5 mt-9 text-base text-black bg-white rounded-[50px] max-md:pl-5"
            >
              Learn More
            </a>
          </div>
        </div>

        <section class="mt-24 max-md:mt-10 max-md:max-w-full">
          <h2 class="text-lg font-medium leading-7 text-red-700">ASK US</h2>
          <h3 class="mt-7 text-5xl leading-[57.6px] max-md:max-w-full max-md:text-4xl">FAQs</h3>
          <details class="mt-8">
            <summary class="flex gap-5 py-4 text-2xl leading-8 cursor-pointer max-md:flex-wrap">
              <span class="flex-1 max-md:max-w-full">
                Gorem ipsum dolor sit amet, consectetur adipiscing elit.
              </span>
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/75c0801a10942a263825ed1fbdb53e2061f97dd387319e92251cacd1ec07539a?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt=""
                class="shrink-0 self-start w-8 aspect-square"
              />
            </summary>
            <p class="text-base leading-6 mt-4 max-md:max-w-full">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in
              eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum
              nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id
              rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.
            </p>
          </details>
          <details class="mt-6 border-t border-black border-opacity-20">
            <summary class="flex gap-5 py-4 text-2xl leading-8 cursor-pointer max-md:flex-wrap">
              <span class="flex-1 max-md:max-w-full">
                Qorem ipsum dolor sit amet, consectetur adipiscing elit.
              </span>
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/07e4b35cb0147a60165883928c8972d04e74734db02e6c14ed05d25e3046d62d?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt=""
                class="shrink-0 self-start w-8 aspect-square"
              />
            </summary>
          </details>
          <details class="border-t border-black border-opacity-20">
            <summary class="flex gap-5 py-4 text-2xl leading-8 cursor-pointer max-md:flex-wrap">
              <span class="flex-1 max-md:max-w-full">
                Corem ipsum dolor sit amet, consectetur adipiscing elit.
              </span>
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/07e4b35cb0147a60165883928c8972d04e74734db02e6c14ed05d25e3046d62d?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt=""
                class="shrink-0 self-start w-8 aspect-square"
              />
            </summary>
          </details>
          <details class="border-t border-black border-opacity-20">
            <summary class="flex gap-5 py-4 text-2xl leading-8 cursor-pointer max-md:flex-wrap">
              <span class="flex-1 max-md:max-w-full">
                Qorem ipsum dolor sit amet, consectetur adipiscing elit.
              </span>
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/07e4b35cb0147a60165883928c8972d04e74734db02e6c14ed05d25e3046d62d?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt=""
                class="shrink-0 self-start w-8 aspect-square"
              />
            </summary>
          </details>
          <details class="border-t border-black border-opacity-20">
            <summary class="flex gap-5 py-4 text-2xl leading-8 cursor-pointer max-md:flex-wrap">
              <span class="flex-1 max-md:max-w-full">
                Gorem ipsum dolor sit amet, consectetur adipiscing elit.
              </span>
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/07e4b35cb0147a60165883928c8972d04e74734db02e6c14ed05d25e3046d62d?apiKey=150e32e9ad6f4daaaa26aad342fc89bf&&apiKey=150e32e9ad6f4daaaa26aad342fc89bf"
                alt=""
                class="shrink-0 self-start w-8 aspect-square"
              />
            </summary>
          </details>
        </section>
      </section>
    </Fragment>
  );
};

export default Frontpage;
